<?php

require_once "lib/pclerror.lib.php3";
require_once "lib/pcltar.lib.php3";
require_once "lib/pcltrace.lib.php3";

?>
