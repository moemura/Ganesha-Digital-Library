<?
		$gdl_db_conf["host"]="";
			$gdl_db_conf["uname"]="";
			$gdl_db_conf["password"]="";
			$gdl_db_conf["name"]="";
			$gdl_db_conf["prefix"]="";
			?>
