<?
$gdl_type['s1'] 		= "Undergraduate Theses";
$gdl_type['s2'] 		= "Master Theses";
$gdl_type['s3'] 		= "PhD Theses";
$gdl_type['grey'] 		= "Gray literature";
$gdl_type['clipp'] 		= "Clipping";
$gdl_type['course'] 	= "Course Material";
$gdl_type['dlearn'] 	= "Distance Learning";
$gdl_type['drawing'] 	= "Drawing and Painting";
$gdl_type['emall'] 		= "E-Mall Commodities";
$gdl_type['quiz'] 		= "Examination & Quiz Sample";
$gdl_type['expert'] 	= "Expertise Directory";
$gdl_type['book'] 		= "Book";
$gdl_type['heritage'] 	= "Heritage";
$gdl_type['web'] 		= "Internet Directory";
$gdl_type['jou'] 		= "Journal";
$gdl_type['image'] 		= "Images";
$gdl_type['mmedia'] 	= "Multimedia";
$gdl_type['news'] 		= "News";
$gdl_type['org'] 		= "Organization Directory";
$gdl_type['proc'] 		= "Proceeding";
$gdl_type['person'] 	= "People Directory";
$gdl_type['poem'] 		= "Poem";
$gdl_type['publ'] 		= "Publication";
$gdl_type['res'] 		= "Research Report";
$gdl_type['sw'] 		= "Software";
$gdl_type['disc'] 		= "Discussion";
?>