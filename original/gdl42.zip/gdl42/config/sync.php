<?
			# Automatically generated on 2007-01-16 15:42:06
		
			# ******* Repository Name
			$gdl_sync['sync_repository_name'] 			= "";
			$gdl_sync['sync_repository_id'] 			= "";
			
			# ******** Hub Server
			$gdl_sync['sync_hub_server_name']  		= "";
			$gdl_sync['sync_hub_server_port']  		= "";
		
			# ******** Proxy
			$gdl_sync['sync_use_proxy']  				= "";
			$gdl_sync['sync_proxy_server_address']  	= "";
			$gdl_sync['sync_proxy_server_port']  		= "";
		
			# ********* OAI Script for request
			$gdl_sync['sync_oai_script']  				= "";
			$gdl_sync['sync_opt_script']  				= "";
			$gdl_sync['sync_harvest_node']   			= "";
			$gdl_sync['sync_harvest_from']   			= "0000-00-00T00:00:00Z";
			$gdl_sync['sync_harvest_until']  			= "0000-00-00T00:00:00Z";
			$gdl_sync['sync_harvest_set']  	 		= "";
			
			# ********* Other options
			$gdl_sync['sync_count_records']  = "";
			$gdl_sync['sync_show_response']  = "";
			$gdl_sync['sync_fragment_size']  = "";
			
			?>