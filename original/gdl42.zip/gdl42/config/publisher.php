<?
			# Automatically generated on 2007-01-13 13:24:25
		
			$gdl_publisher['id']  = "";
			$gdl_publisher['serialno']  = "";
			$gdl_publisher['type']  = "";
			$gdl_publisher['connection']  = "";
			$gdl_publisher['apps']  = "";		
			$gdl_publisher['publisher']  = "";
			$gdl_publisher['orgname']  = "";
			$gdl_publisher['hostname']  = "";
			$gdl_publisher['ipaddress']  = "";
			$gdl_publisher['contact']   = "";
			$gdl_publisher['address']  = "";
			$gdl_publisher['city']  = "";
			$gdl_publisher['region']  = "";
			$gdl_publisher['country']  = "";
			$gdl_publisher['phone']  = "";
			$gdl_publisher['fax']  = "";
			$gdl_publisher['admin']  = "";
			$gdl_publisher['cko']  = "";
			$gdl_publisher['network']  = "";
			$gdl_publisher['hubserver']  = "";
			?>