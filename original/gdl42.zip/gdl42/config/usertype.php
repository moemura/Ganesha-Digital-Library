<?
$user_type['1'] 	= "Student, Lower Level School";
$user_type['2']		= "Student, Diploma";
$user_type['3']		= "Student, S1";
$user_type['4']		= "Student, S2";
$user_type['5']		= "Student, S3";
$user_type['6']		= "Teacher";
$user_type['7']		= "Lecturer";
$user_type['8']		= "Researcher";
$user_type['9']		= "Librarian";
$user_type['10']	= "Employee, University";
$user_type['11']	= "Employee, Private Company";
$user_type['12']	= "Employee, Public Sector";
$user_type['13']	= "Employee, NGO";
$user_type['14']	= "Public";
$user_type['15']	= "Others";
?>