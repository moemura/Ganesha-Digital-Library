<?
		# Automatically generated on 2007-01-16 15:33:06
		
		# ******** Setting Konfigurasi
		$gdl_folks['folks_fetch_records']  	= "10";
		$gdl_folks['folks_start_date']  		= "0000-00-00T00:00:00Z";
		$gdl_folks['folks_show_page'] 			= "4";
		
		# ******** Option Show Folksonomy
		$gdl_folks['folks_active_option']  	= "1";
		
		#********* Setting Frekuensi
		$gdl_folks['folks_min_frekuensi']  	= "5";
		$gdl_folks['folks_token_per_abjad']  	= "5";
		
		#********* Setting Font Height
		$gdl_folks['folks_max_size_font']  	= "20";
		$gdl_folks['folks_min_size_font']  	= "8";
	
		# ********* Setting background and font color
		$gdl_folks['folks_bg_color']  			= "000000";
		$gdl_folks['folks_font_color']  		= "cccccc";
		?>