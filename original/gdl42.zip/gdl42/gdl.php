<?
$gdl_mod = $_GET['mod'];
$gdl_op = $_GET['op'];
if (!isset($gdl_op)) $gdl_op = "index";
include ("./main.php");
?>
