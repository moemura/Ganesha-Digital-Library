<?php
$t['color_dark'] = "#0000CC";
$t['color_light_more'] = "#ccccff";

$l['timeout'] = "TIMEOUT";
$l['failed']="FAILED";
$l['connected'] = "CONNECT";
?>