<?

if (eregi("conf.php",$_SERVER['PHP_SELF'])) {
    die();
}

$gdl_modul['name'] = _UPLOAD;
//$gdl_menu['index'] = _STEP1;
//$gdl_menu['step2'] = _STEP2;
//$gdl_menu['step3'] = _STEP3;

?>