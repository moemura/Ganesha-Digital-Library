<?php

if (eregi("indonesian.php",$_SERVER['PHP_SELF'])) {
    die();
}

define("_CURRENTMETADATA","Metadata saat ini");
define("_DESCRIPTION","Deskripsi");
define("_EDIT","Ubah");
define("_EXPERTISE","Profesional, Ahli, Peneliti, dll");
define("_FOLDER","Folder");
define("_FILE","File");
define("_IMAGE","Image, Photo, Picture, dll");
define("_MODE","Mode Akses");
define("_NEXT","Selanjutnya");
define("_NEWMETADATAPROPERTY","Properti / Profile Metadata Baru");
define("_MULTIMEDIA","Multimedia");
define("_OWNER","Pemilik");
define("_OTHERS","Lain - Lain");
define("_ORGANIZATION","Organisasi, Institusi, dll");
define("_RESET","Kosongkan");
define("_STEP1","Step 1. Pilih Skema Metadata");
define("_STEP2","Step 2. Buat / Update Metadata");
define("_STEP3","Step 3. Upload / Update File");
define("_SOURCEPATH","Alamat File");
define("_SUBMIT","Submit");
define("_THISMETADATAHASBEENUPLOAD","Metadata ini sudah di-upload");
define("_THISMETADATAHASBEENUPDATE","Metadata ini sudah di-update");
define("_TITLE","Judul");
define("_UPLOADOREDIT","Upload / Edit Metadata");
define("_UPLOADFAIL","Upload tidak berhasil");
define("_UPLOADINFO","Metadata Anda mempunyai properti sebagai berikut, lakukan perubahan yg dikehendaki.");
define("_UPLOADNEFILE","Upload baru ...");
define("_CURRENTFOLDER","Folder Saat ini");
define("_WHATSCHEMA","Apa yang akan anda upload ?");
define("_DIRECTORYERROR","Anda tidak dapat upload metadata pada direktori ini, Anda dapat upload pada direktori <a href='./gdl.php?mod=mydocs'>My Documents</a>");
?>