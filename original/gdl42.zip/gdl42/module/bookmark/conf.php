<?
/***************************************************************************
                          conf.php  -  configuration file for home module
                             -------------------
    begin                : June 19, 2004
    copyright            : (C) 2004 Hayun Kusumah, KMRG ITB
    email                : hayun@kmrg.itb.ac.id
	reviewer             : Beni Rio Hermanto (benirio@kmrg.itb.ac.id)
	
 ***************************************************************************/
if (eregi("conf.php",$_SERVER['PHP_SELF'])) {
    die();
}

$gdl_modul['name'] = _BOOKMARK;
//$gdl_menu['$gdl_op'] = _NAME;

?>