<?php
/***************************************************************************
                         /module/bookmark/lang/indonesian.php
                             -------------------
    copyright            : (C) 2007 Lastiko Wibisono, KMRG ITB
    email                : leonhart_4321@yahoo.com
    reviewer             : Beni Rio Hermanto (benirio@kmrg.itb.ac.id)
	
 ***************************************************************************/
if (eregi("indonesian.php",$_SERVER['PHP_SELF'])) {
    die();
}

define("_BOOKMARKISEMPTY","Bookmark tidak ada");
define("_MYBOOKMARK","My Bookmark");
define("_TITLE","Identifier / Judul");
define("_USERREQUESTMOVE","Pindah ke permintaan user");
define("_BOOKMARKMOVE","Pindah ke bookmark");
define("_USERREQUESTISEMPTY","Permintaan user kosong");
define("_USERREQUEST","Permintaan user");
define("_SENT","Waktu Kirim");
define("_RESPONSE","Komentar");
define("_DELETEBOOKMARK","Hapus Bookmark");
define("_DELETEREQUEST","Hapus Permintaan");
define("_GIVEYOURMESSAGE","Berikan komentar Anda");
define("_FROM","Dari");
define("_DATESENT","Tanggal Kirim");
define("_AUTHOR","Pengarang");
define("_SEND","Kirim");
define("_INSERTCOMMENTSUCCESS","Pesan telah terkirim");
define("_INSERTCOMMENTFAILED","Pesan gagal terkirim");
?>