<?php

/***************************************************************************
                         /module/bookmark/lang/english.php
                             -------------------
    copyright            : (C) 2007 Lastiko Wibisono, KMRG ITB
    email                : leonhart_4321@yahoo.com
    reviewer			 : Beni Rio Hermanto (benirio@kmrg.itb.ac.id)
	
 ***************************************************************************/

if (eregi("indonesian.php",$_SERVER['PHP_SELF'])) {
    die();
}

define("_BOOKMARKISEMPTY","Bookmark is empty");
define("_MYBOOKMARK","My Bookmark");
define("_TITLE","Identifier / Title");
define("_USERREQUESTMOVE","Move to request");
define("_BOOKMARKMOVE","Move to bookmark");
define("_USERREQUESTISEMPTY","User request is empty");
define("_USERREQUEST","User request");
define("_SENT","Sent");
define("_RESPONSE","Comment");
define("_DELETEBOOKMARK","Delete Bookmark");
define("_DELETEREQUEST","Delete Request");
define("_GIVEYOURMESSAGE","Give your message here");
define("_FROM","From");
define("_DATESENT","Date Sent");
define("_AUTHOR","Author");
define("_SEND","Send");
define("_INSERTCOMMENTSUCCESS","Message has been sent");
define("_INSERTCOMMENTFAILED","Message sending failed");

?>