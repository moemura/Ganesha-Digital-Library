<?php
if (eregi("indonesian.php",$_SERVER['PHP_SELF'])) {
    die();
}

define("_ORGANIZATIONFOLDER","Folder Organisasi");
define("_DOESNOTEXISTDOYOUWANTTOCREATE","tidak ada. Apa Anda ingin membuat folder tersebut ?");
define("_ORGANIZATIONCREATED","Organisasi telah dibuat");
define("_ORGANIZATIONEXIST","Folder Organization sudah ada");
define("_ORGANIZATIONCREATEFAILED","Organisasi gagal dibuat");
define("_ORGANIZATIONNAME","Nama Organisasi");
define("_ORGANIZATIONADDNEW","Penambahan Organisasi");
define("_ORGANIZATIONEDITING","Perubahan Organisasi");
define("_ADDORGANIZATIONFAILED","Penambahan Organisasi gagal");
define("_ADDORGANIZATIONSUCCESS","Penambahan Organisasi berhasil");
define("_EDITORGANIZATIONFAILED","Perubahan Organisasi gagal");
define("_EDITORGANIZATIONSUCCESS","Perubahan Organisasi berhasil");
define("_DELETEORGANIZATIONCONFIRMATION","Apakah Anda yakin ingin menghapus Organisasi ini ? ");
define("_DELETEORGANIZATIONSUCCESS","Penghapusan organisasi berhasil");
define("_DELETEORGANIZATIONFAILED","Penghapusan organisasi gagal");
define("_YESSURE","Ya, Saya yakin");
define("_CONFIRMATION","Konfirmasi Penghapusan");
define("_ACTION","Aksi");
define("_ADD","Tambah");
define("_EDIT","Ubah");

?>