<?
$db_source["host"]="localhost";
$db_source["uname"]="root";
$db_source["password"]="idlnhub";
$db_source["name"]="gdlPP";

$gdl_modul['name'] = _MIGRATION4042;
$gdl_menu['configuration'] = _CONFIGURATION;
?>