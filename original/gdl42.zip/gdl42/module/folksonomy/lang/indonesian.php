<?php
if (eregi("indonesian.php",$_SERVER['PHP_SELF'])) {
    die();
}

define("_FOLKSONOMY","Folksonomy");
define("_GARBAGE","Filter Kata");
define("_UPDATE","Update");
define("_AKTIVE_FOLKSONOMY_OPTION","Aktifkan Folksonomy");
define("_MIN_FREKUENSI","Minimum frekuensi");
define("_TOKEN_PER_ABJAD","Token tiap abjad");
define("_MAX_FONT_SIZE","Tinggi maksimum token");
define("_MIN_FONT_SIZE","Tinggi minimum token");
define("_BG_COLOR","Warna latar belakang");
define("_FONT_COLOR","Warna Dasar Token");
define("_SAVECHANGES","Simpan");
define("_OPTIONSAVE","Data Berhasil disimpan");
define("_OPTIONSAVEFAILED","Data Berhasil gagal disimpan");
define("_INS_STOPWORD","Masukan kata baru untuk penyaringan");
define("_ADD_STOPWORD","Tambahkan");
define("_STOPWORDDISPLAYING","Daftar kata untuk penyaringan ");
define("_OF","dari");
define("_PAGE","Halaman");
define("_STOPWORDDELETE","Hapus");
define("_NO_TOKEN","No");
define("_TOKEN","Kata");
define("_STOPWORD_ACTION","Aksi");
define("_FOLKSONOMYISPLAYING","Daftar kata");
define("_FOLKSONOMYWORD","kata untuk folksonomy");
define("_FREKUENSI","Frekuensi");
define("_FOLKSONOMY_ACTION","Aksi");
define("_RESET_FOLKSONOMY","Hapus Folksonomy");
define("_UPDATE_FOLKSONOMY","Susun Folksonomy");
define("_CLEAN_STOPWORD","Penyaringan Kata");
define("_STOPWORDMANAGEMENT","Manajemen Penyaringan Kata");
define("_FOLKSONOMYMANAGEMENT","Manajemen Penyusunan Folksonomy");
define("_TOKENDELETE","Hapus");
define("_NUMFETCHRECORD","Limit Update Record");
define("_STARTDATE","Batas Tanggal Awal");
define("_SHOW_RECORDS","Record Per Halaman");
define("_SUCCESS_INSERT_STOPWORD","Berhasil menambahkan kata sampah");
define("_FAILED_INSERT_STOPWORD","Gagal menambahkan kata sampah");
define("_DUPLICATE_STOPWORD","Kata sampah terduplikasi");
?>