<?php
if (eregi("english.php",$_SERVER['PHP_SELF'])) {
    die();
}

define("_FOLKSONOMY","Folksonomy");
define("_GARBAGE","Stop Word");
define("_UPDATE","Update");
define("_AKTIVE_FOLKSONOMY_OPTION","Activated Folksonomy");
define("_MIN_FREKUENSI","Minimum Frequency");
define("_TOKEN_PER_ABJAD","Token per alphabet");
define("_MAX_FONT_SIZE","Maximum Height Token");
define("_MIN_FONT_SIZE","Minimum Height Token");
define("_BG_COLOR","Background Color");
define("_FONT_COLOR","Basic Font Color");
define("_SAVECHANGES","Save");
define("_OPTIONSAVE","Data have been accomplished to be saved");
define("_OPTIONSAVEFAILED","Data have been failed to be saved");
define("_INS_STOPWORD","New stop word");
define("_ADD_STOPWORD","Add");
define("_STOPWORDDISPLAYING","List stop word ");
define("_OF","from");
define("_PAGE","Page");
define("_STOPWORDDELETE","Delete");
define("_NO_TOKEN","No");
define("_TOKEN","Word");
define("_STOPWORD_ACTION","Action");
define("_FOLKSONOMYISPLAYING","List token");
define("_FOLKSONOMYWORD","word for folksonomy");
define("_FREKUENSI","Frequency");
define("_FOLKSONOMY_ACTION","Action");
define("_RESET_FOLKSONOMY","Reset Folksonomy");
define("_UPDATE_FOLKSONOMY","Update Folksonomy");
define("_CLEAN_STOPWORD","Clean Stop Word");
define("_STOPWORDMANAGEMENT","Filtering Stop Word Management");
define("_FOLKSONOMYMANAGEMENT","Folksonomy Management");
define("_TOKENDELETE","Delete");
define("_NUMFETCHRECORD","Limit for Update Record");
define("_STARTDATE","Internal Boundary Date");
define("_SHOW_RECORDS","Records Per Page");
define("_SUCCESS_INSERT_STOPWORD","Inserting Stop Word Successful");
define("_FAILED_INSERT_STOPWORD","Failed inserting stop word");
define("_DUPLICATE_STOPWORD","Duplicate Stop Word");
?>