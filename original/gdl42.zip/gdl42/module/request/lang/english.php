<?php
if (eregi("english.php",$_SERVER['PHP_SELF'])) {
    die();
}

define("_SEARCHPUBLISHER","Search Publisher by ID or Name");
define("_NO","No.");
define("_TITLE","Identifier / Title");
define("_SENT","Sent");
define("_COMMENT","Comment");
define("_ACTION","Action");
define("_REQUESTDISPLAYING","Displaying Request");
define("_SEARCHREQUEST","Search request by User ID");
define("_SEARCH","Search");
define("_REQUESTDELETESUCCESS","Request deletion successfully");
define("_REQUESTDELETEFAILED","Request deletion failed");
define("_CANNOTFOUNDREQUESTDATA","Cannot found request data");
define("_FROM","From");
define("_AUTHOR","Author");
define("_GIVEYOURMESSAGE","Give your message here");
define("_SEND","Send");
define("_INSERTCOMMENTSUCCESS","Insert comment successfully");
define("_INSERTCOMMENTFAILED","Failed to insert comment");
define("_OF","of");
define("_PAGE","Page");


?>