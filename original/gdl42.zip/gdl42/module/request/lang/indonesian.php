<?php
if (eregi("indonesian.php",$_SERVER['PHP_SELF'])) {
    die();
}

define("_SEARCHREQUEST","Pencarian Permintaan dengan ID User");
define("_NO","No.");
define("_TITLE","Identifier / Judul");
define("_SENT","Dikirim");
define("_COMMENT","Komentar");
define("_ACTION","Aksi");
define("_REQUESTDISPLAYING","Menampilkan Permintaan");
define("_SEARCHREQUEST","Pencarian Permintaan dengan ID User");
define("_SEARCH","Cari");
define("_FROM","Dari");
define("_REQUESTDELETESUCCESS","Penghapusan permintaan berhasil");
define("_REQUESTDELETEFAILED","Penghapusan permintaan gagal");
define("_CANNOTFOUNDREQUESTDATA","Tidak dapat menemukan data permintaan");
define("_AUTHOR","Pengarang");
define("_GIVEYOURMESSAGE","Berikan pesan Anda");
define("_SEND","Kirim");
define("_INSERTCOMMENTSUCCESS","Pengiriman komentar berhasil");
define("_INSERTCOMMENTFAILED","Pengiriman komentar gagal");
define("_OF","Dari");
define("_PAGE","Halaman");
define("_ADD","Tambah");
define("_EDIT","Ubah");
?>