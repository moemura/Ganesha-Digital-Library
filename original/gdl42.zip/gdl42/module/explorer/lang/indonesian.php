<?php

if (eregi("indonesian.php",$_SERVER['PHP_SELF'])) {
    die();
}

define("_ACTION","Perintah");
define("_ADDFOLDER","Tambah Folder");
define("_ADDNEWFOLDER","Tambah Folder Baru");
define("_CONFIRMATION","Konfirmasi");
define("_CHILD","Sub Folder");
define("_DISPLAYINGMETADATA","Menampilkan metadata");
define("_DATE","Tanggal");
define("_DELETEFOLDER","Hapus Folder");
define("_DELETEMETADATA","Hapus Metadata");
define("_DELETEFOLDERCONFIRMATION","Anda yakin menghapus folder ini, termasuk metadata didalamnya");
define("_DELETEMETADATACONFIRMATION","Anda yakin menghapus metadata ini");
define("_EDIT","Ubah");
define("_FOLDER","Folder");
define("_METADATAINFOLDER","Metadata dalam folder");
define("_METADATAS","Metadata");
define("_METADATA","Metadata");
define("_MODE","Mode");
define("_NAME","Nama");
define("_OF","dari");
define("_OWNER","Pemilik");
define("_PAGE","Halaman");
define("_PROPERTY","Properti");
define("_PARENT","Folder Induk");
define("_PROPERTYFOLDER","Properti Folder");
define("_PROPERTYMETADATA","Properti Metadata");
define("_SUBFOLDERON","Sub Folder");
define("_SUBMIT","Submit");
define("_TITLE","Identifier / Judul");
define("_UPLOADMETADATA","Upload Metadata");
define("_WORKGROUP","Workgroup");
define("_YESDELETE","Ya, hapus");
define("_RESET","Reset");
define("_EDITFOLDER","Edit Folder");
define("_BACK","Kembali");
define("_CANNOTDELETEFOLDERCONFIRMATION","Folder ini mempunyai sub folder, Anda tidak bisa menghapusnya");
define("_MULTIVIEW","Tampilan ganda");
define("_SINGLEVIEW","Tampilan satu");
define("_MOVE","Pindahkan");
define("_DATEMODIFIED","Tanggal Perubahan");
?>