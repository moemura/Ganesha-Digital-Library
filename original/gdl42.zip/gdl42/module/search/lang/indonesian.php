<?php

if (eregi("indonesian.php",$_SERVER['PHP_SELF'])) {
    die();
}

define("_ADVANCESEARCH","Pencarian Metadata");
define("_ALLMETADATA","Semua Artikel");
define("_DOCUMENT","Dokumen");
define("_IMAGE","Image");
define("_KEYWORD","Kata Kunci");
define("_MULTIMEDIA","Multimedia");
define("_METADATATYPE","Tipe");
define("_ORGANIZATION","Organisasi");
define("_PEOPLE","Profesional");
define("_SEARCHRESULTFOR","Hasil pencarian untuk ");
define("_SEARCHALL","Semua");
define("_SEARCHNOTFOUND","Pencarian tidak ditemukan");
define("_CATALOGS","Katalog");
define("_TITLE","Judul");
define("_AUTHOR","Penulis");
define("_YEAR","Tahun");
define("_PUBLISHER","Publisher");
define("_ISBN","ISBN");
define("_SUBJECTHEADING","Subyek");
define("_CLASSIFICATION","Klasifikasi");
define("_CALLNUMBER","Nomor Panggil");
define("_ABSTRACT","Abstraksi");
define("_FULLNAME","Nama Lengkap");
define("_ADDRESS","Alamat");
define("_INTEREST","Minat");
define("_EXPERTISE","Keahlian");
define("_EXPERIENCE","Pengalaman");
define("_ALL","All");
define("_NAME","Name");
define("_PERIOD","Periode");
define("_LOCATION","Lokasi");
define("_CLASSIFICATION","Klasifikasi");
define("_CALLNUMBER","Nomor Hubung");
define("_DDCEDITION","Edisi DDC");
define("_LOCALCLASSIFICATION","Klasifikasi Lokal");
define("_AUTHOR","Penerbit");
define("_AUTHORCORPORATE","Perusahaan Penerbit");
define("_CONFERENCE","Konferensi");
define("_TITLEOFJOURNAL","Judul Jurnal");
define("_TITLE","Judul");
define("_ALTERNATIVETITLE","Judul Alternatif");
define("_DESCRIPTION","Deskripsi");
define("_EDITION","Edisi");
define("_PLACEOFPUBLISHER","Tempat Publisher");
define("_DIMENTION","Dimensi");
define("_ILLUSTRATION","Ilustrasi");
define("_HEIGHT","Height");
define("_SERIES","Seri");
define("_NOTE","Catatan");
define("_BIBLIOGRAPHY","Bibliografi");
define("_SUMMARY","Kesimpulan atau Kutipan");
define("_SUBJECT","Subyek");
define("_COAUTHOR","Co-Author dan Editor");
define("_COAUTHORCORPORATE","Perusahaan Co-Author");
define("_IDENTIFICATION","Identifikasi");
?>