<?php

if (eregi("indonesian.php",$_SERVER['PHP_SELF'])) {
    die();
}

define("_ADVANCESEARCH","Advance Search");
define("_ALLMETADATA","All Metadata");
define("_DOCUMENT","Document");
define("_IMAGE","Image");
define("_KEYWORD","Keyword");
define("_MULTIMEDIA","Multimedia");
define("_METADATATYPE","Type");
define("_ORGANIZATION","Organization");
define("_PEOPLE","People");
define("_SEARCHRESULTFOR","Search Result for ");
define("_SEARCHALL","Search All");
define("_SEARCHNOTFOUND","Search Not Found");
define("_CATALOGS","Catalogues");
define("_TITLE","Title");
define("_AUTHOR","Author");
define("_YEAR","Year");
define("_PUBLISHER","Publisher");
define("_ISBN","ISBN");
define("_SUBJECTHEADING","Subject Heading");
define("_CLASSIFICATION","Classification");
define("_CALLNUMBER","Call Number");
define("_ABSTRACT","Abstract");
define("_PEOPLE","Peoples");
define("_FULLNAME","Full Name");
define("_ADDRESS","Address");
define("_INTEREST","Interest");
define("_EXPERTISE","Expertise");
define("_EXPERIENCE","Experience");
define("_ALL","All");
define("_NAME","Name");
define("_PERIOD","Period");
define("_LOCATION","Location");
define("_CLASSIFICATION","Classification");
define("_CALLNUMBER","Call Number");
define("_DDCEDITION","DDC Edition");
define("_LOCALCLASSIFICATION","Local Classification");
define("_AUTHOR","Author");
define("_AUTHORCORPORATE","Author Corporate");
define("_CONFERENCE","Conference");
define("_TITLEOFJOURNAL","Title of Journal");
define("_TITLE","Title");
define("_ALTERNATIVETITLE","Alternative Title");
define("_DESCRIPTION","Description");
define("_EDITION","Edition");
define("_PLACEOFPUBLISHER","Place of Publisher");
define("_DIMENTION","Dimention");
define("_ILLUSTRATION","Illustration");
define("_HEIGHT","Height");
define("_SERIES","Series");
define("_NOTE","Note");
define("_BIBLIOGRAPHY","Bibliography");
define("_SUMMARY","Summary or Annotation");
define("_SUBJECT","Subject");
define("_COAUTHOR","Co-Author and Editor");
define("_COAUTHORCORPORATE","Co-Author Corporate");
define("_IDENTIFICATION","Identification");


?>