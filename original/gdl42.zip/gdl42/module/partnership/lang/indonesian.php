<?php

define("_PARTNERSHIP","Partner");
define("_PARTNERNO","No");
define("_PARTNERID","Partner ID");
define("_PARTNERNAME","Nama Partner");
define("_HOSTNAME","Hostname");
define("_REMOTEUSER","Remote");
define("_PAGE","Halaman");
define("_PARTNERDISPLAYING","Daftar Partner");
define("_OF","dari");
define("_SEARCHPARTNER","Pencarian");
define("_PARTNERSEARCH","Cari");

?>