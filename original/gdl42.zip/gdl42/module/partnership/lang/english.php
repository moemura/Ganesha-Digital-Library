<?php

define("_PARTNERSHIP","Partner");
define("_PARTNERNO","No");
define("_PARTNERID","Partner ID");
define("_PARTNERNAME","Partner Name");
define("_HOSTNAME","Hostname");
define("_REMOTEUSER","Remote");
define("_PAGE","Page");
define("_PARTNERDISPLAYING","List of Partner");
define("_OF","from");
define("_SEARCHPARTNER","Searching partner");
define("_PARTNERSEARCH","Search");
?>